chrome.runtime.onInstalled.addListener(() => {
  console.log("ReadAble background worker installed.");
});